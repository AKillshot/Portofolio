// ==========================
// Dark/Light Mode with Live Sync Across All Tabs
// ==========================
(function () {
    const body = document.body;
    const toggleBtn = document.getElementById('theme-toggle');
    const darkClass = 'dark-mode';
    const storageKey = 'theme-mode';
    let channel;

    // Create BroadcastChannel only if supported
    if ('BroadcastChannel' in window) {
        channel = new BroadcastChannel('theme_channel');
    }

    // Apply theme mode
    function setMode(mode) {
        body.classList.toggle(darkClass, mode === 'dark');
        if (toggleBtn) toggleBtn.textContent = mode === 'dark' ? '🌙' : '☀️';
    }

    // Initial mode from localStorage or default to dark
    function setInitialMode() {
        let mode = localStorage.getItem(storageKey) || 'dark';
        setMode(mode);
    }

    // Toggle mode and broadcast to other tabs
    function toggleMode() {
        const isDark = body.classList.contains(darkClass);
        const newMode = isDark ? 'light' : 'dark';
        localStorage.setItem(storageKey, newMode);
        setMode(newMode);

        // Send message to other tabs if BroadcastChannel is supported
        if (channel) {
            channel.postMessage({mode: newMode, reload: true});
        }
    }

    // On load
    setInitialMode();

    // Toggle button click
    if (toggleBtn) {
        toggleBtn.addEventListener('click', toggleMode);
    }

    // Listen for changes from other tabs/pages via BroadcastChannel
    if (channel) {
        channel.addEventListener('message', (event) => {
            if (event.data && event.data.reload) {
                setMode(event.data.mode);
                location.reload(); // Force reload for instant update
            } else {
                setMode(event.data);
            }
        });
    }

    // Fallback: Listen for changes from localStorage
    window.addEventListener('storage', function (event) {
        if (event.key === storageKey && event.newValue) {
            setMode(event.newValue);
        }
    });
})();

// ==========================
// Burger Menu, Smooth Scroll, Active Link Highlight
// ==========================
document.addEventListener('DOMContentLoaded', function () {
    // Burger menu
    const burger = document.getElementById('burger');
    const navMenu = document.getElementById('nav-menu');
    if (burger && navMenu) {
        burger.addEventListener('click', () => {
            burger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        burger.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                burger.classList.toggle('active');
                navMenu.classList.toggle('active');
            }
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth' });
            }
        });
    });

    // Section highlighting in navbar
    window.addEventListener('scroll', () => {
        const sections = document.querySelectorAll('section, .hero-content');
        const navLinks = document.querySelectorAll('.navbar ul li a');
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            if (window.scrollY >= sectionTop) {
                current = section.getAttribute('id');
            }
        });
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (current && link.getAttribute('href').includes(current)) {
                link.classList.add('active');
            }
        });
    });
});
